const TestButton = ({...otherProps})=>(
    <input {...otherProps} />
)

export default TestButton