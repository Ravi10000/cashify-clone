import CustomButton from "../custom-buttom/custom-button.component";

const SignOut = () => {
  return (
    <button className="bg-red-500 text-white">Sign Out</button>
  );
}
export default SignOut;